#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2023-01-19 22:08:32

#include "Arduino.h"
#include "Arduino.h"
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_task_wdt.h"
#include "RFID_command.h"
#include "SPI.h"
#include "TFT_22_ILI9225.h"
#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include "ESP32Time.h"

void setup( void ) ;
void vTaskRFID( void *pvParameters );
void vTaskTFT( void *pvParameters ) ;
void vTaskWRITESD( void *pvParameters );
void vTaskBUZZER( void *pvParameters );
static void  IRAM_ATTR  vExampleInterruptHandler( void ) ;
void loop() ;

#include "ESP1.ino"


#endif
